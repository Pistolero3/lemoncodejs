const hoteles = {
  Posada: {
    nombre: "Hotel La Posada",
    ubicacion: "Almogia (Malaga)",
    picture:
      "https://www.hotelscombined.es/himg/8f/ae/d9/leonardo-2016907-HOTEL_O-291872.jpg",
  },

  Julieta: {
    nombre: "Hotel Bella Julieta",
    ubicacion: "Barcelona",
    picture:
      "https://suitopiahotel.com/wp-content/uploads/sites/2/2020/07/Port-4.jpg",
  },
};

const stars = {
  1: "&#9733" + "&#9734" + "&#9734" + "&#9734" + "&#9734",
  2: "&#9733" + "&#9733" + "&#9734" + "&#9734" + "&#9734",
  3: "&#9733" + "&#9733" + "&#9733" + "&#9734" + "&#9734",
  4: "&#9733" + "&#9733" + "&#9733" + "&#9733" + "&#9734",
  5: "&#9733" + "&#9733" + "&#9733" + "&#9733" + "&#9733",
};

var hotel = prompt("A quien quiere puntuar, a Posada o a Julieta?");
var score = prompt("Introduzca la puntuación del hotel del 1 al 5");
var confirmation = confirm("Desea que su reseña sea anonima?");

document.getElementById("hotelName").innerHTML = hoteles[hotel].nombre;
document.getElementById("hotelLocation").innerHTML = hoteles[hotel].ubicacion;
document.getElementById("foto").src = hoteles[hotel].picture;
document.getElementById("puntuacion").innerHTML = stars[score];
document.getElementById("box").checked = confirmation;
