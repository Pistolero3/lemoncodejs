function fillUp() {
  document.getElementById("name").value = "Antonio";
  document.getElementById("surname").value = "Morales";
  document.getElementById("image").src = "./myprofile.jpeg";
}

function cleanUp() {
  document.getElementById("name").value = "";
  document.getElementById("surname").value = "";
  document.getElementById("image").src = "null";
}

function sendToConsole() {
  let name = document.getElementById("name").value;
  let lastname = document.getElementById("surname").value;
  if ((name || lastname) == "") {
    alert("Please, insert data");
  } else {
    console.log(name + " " + lastname);
  }
}
